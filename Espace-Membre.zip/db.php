<?php

try {
$db = new PDO("mysql:host=localhost;dbname=info;charset=utf8",'name','pass');

} catch (Exception $e) {
echo "database not connected";
}
